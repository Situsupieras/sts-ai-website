# Si Tus Supieras El Poder de la IA - Sitio Web B2B

## 🚀 Descripción del Proyecto

Sitio web corporativo de alta conversión para "Si Tus Supieras El Poder de la IA", una empresa líder en soluciones de inteligencia artificial para empresas B2B. El proyecto está diseñado con una arquitectura moderna, optimizada para SEO/AEO y enfocada en maximizar las conversiones.

## 🏗️ Arquitectura del Proyecto

### Tecnologías Principales
- **Next.js 14** - Framework React con App Router
- **TypeScript** - Tipado estático para mayor robustez
- **Tailwind CSS** - Framework CSS utility-first
- **Framer Motion** - Animaciones fluidas y profesionales
- **Lucide React** - Iconografía moderna y consistente

### Características Técnicas Clave

#### 🎯 Optimización de Conversión
- **Personalización basada en GeoIP** - Contenido adaptado por ubicación
- **Cookies inteligentes** - Seguimiento de comportamiento del usuario
- **Formularios multietapas** - Reducción de fricción en la conversión
- **CTAs estratégicos** - Ubicados en puntos de máxima atención

#### 🔍 SEO/AEO Avanzado
- **Meta tags dinámicos** - Optimización por página
- **Schema markup** - Estructura de datos para motores de búsqueda
- **Sitemap automático** - Indexación optimizada
- **Open Graph** - Compartir en redes sociales
- **Canonical URLs** - Evitar contenido duplicado

#### 📊 Analytics y CRM
- **Google Analytics 4** - Seguimiento completo de usuarios
- **Facebook Pixel** - Retargeting y conversiones
- **LinkedIn Insight** - Análisis de audiencia B2B
- **Integración CRM** - Sincronización automática de leads

#### ⚡ Rendimiento
- **Lazy loading** - Carga optimizada de componentes
- **Image optimization** - Formatos WebP/AVIF automáticos
- **Code splitting** - División inteligente de bundles
- **CDN ready** - Distribución global de contenido

## 📁 Estructura del Proyecto

```
STS-ai/
├── app/                          # App Router de Next.js
│   ├── layout.tsx               # Layout principal
│   ├── page.tsx                 # Página principal (HOME)
│   ├── globals.css              # Estilos globales
│   ├── soluciones/              # Página de soluciones
│   ├── industrias/              # Página de industrias
│   ├── resultados/              # Página de resultados
│   ├── metodologia/             # Página de metodología
│   ├── recursos/                # Página de recursos
│   ├── nosotros/                # Página sobre nosotros
│   └── contacto/                # Página de contacto
├── components/                   # Componentes reutilizables
│   ├── layout/                  # Componentes de layout
│   │   ├── header.tsx          # Header con navegación
│   │   └── footer.tsx          # Footer con enlaces
│   ├── sections/                # Secciones de página
│   │   ├── hero-section.tsx    # Hero dinámico
│   │   ├── problem-agitation-solution.tsx # Sección PAS
│   │   ├── social-proof.tsx    # Prueba social
│   │   ├── ai-process-visualizer.tsx # Visualizador IA
│   │   ├── intelligent-form.tsx # Formulario inteligente
│   │   ├── features-section.tsx # Características
│   │   └── cta-section.tsx     # CTA final
│   └── providers/               # Providers de contexto
│       ├── theme-provider.tsx   # Tema claro/oscuro
│       └── analytics-provider.tsx # Analytics
├── lib/                         # Utilidades y configuraciones
├── types/                       # Definiciones de TypeScript
├── utils/                       # Funciones utilitarias
├── hooks/                       # Custom hooks
├── styles/                      # Estilos adicionales
├── public/                      # Archivos estáticos
│   ├── images/                  # Imágenes optimizadas
│   ├── favicon.ico             # Favicon
│   └── site.webmanifest        # PWA manifest
├── package.json                 # Dependencias del proyecto
├── tailwind.config.js          # Configuración de Tailwind
├── next.config.js              # Configuración de Next.js
├── tsconfig.json               # Configuración de TypeScript
└── README.md                   # Documentación
```

## 🎨 Diseño y UX

### Sistema de Diseño
- **Paleta de colores** - Azul primario (#0ea5e9) y púrpura secundario (#d946ef)
- **Tipografía** - Inter para texto, Poppins para títulos
- **Espaciado** - Sistema de 8px base
- **Componentes** - Biblioteca de componentes reutilizables

### Principios de UX
- **Jerarquía visual clara** - Guía la atención del usuario
- **Micro-interacciones** - Feedback visual inmediato
- **Responsive design** - Optimizado para todos los dispositivos
- **Accesibilidad** - Cumple estándares WCAG 2.1

## 📱 Secciones Principales

### 1. Hero Section (HOME)
- **Título dinámico** - Rotación de beneficios clave
- **Visualización IA** - Elemento interactivo central
- **Stats sociales** - Métricas de confianza
- **CTAs múltiples** - Diferentes puntos de conversión

### 2. Problema → Agitación → Solución
- **Problema** - Identificación de desafíos empresariales
- **Agitación** - Consecuencias de no actuar
- **Solución** - Beneficios de implementar IA
- **Resultados esperados** - Métricas específicas

### 3. Prueba Social Multinivel
- **Testimonios** - Casos de éxito reales
- **Logos de clientes** - Credibilidad empresarial
- **Métricas de éxito** - Números impactantes
- **Trust indicators** - Certificaciones y garantías

### 4. Visualizador Interactivo del Proceso de IA
- **5 pasos del proceso** - Explicación visual
- **Controles interactivos** - Navegación manual/automática
- **Detalles por paso** - Información específica
- **Indicador de progreso** - Feedback visual

### 5. Formulario Inteligente Multietapas
- **5 etapas progresivas** - Reducción de fricción
- **Validación en tiempo real** - Feedback inmediato
- **Personalización** - Campos adaptativos
- **Optimización de conversión** - CTAs estratégicos

## 🚀 Instalación y Configuración

### Prerrequisitos
- Node.js 18+ 
- npm o yarn
- Git

### Instalación

1. **Clonar el repositorio**
```bash
git clone https://github.com/tu-usuario/STS-ai.git
cd STS-ai
```

2. **Instalar dependencias**
```bash
npm install
# o
yarn install
```

3. **Configurar variables de entorno**
```bash
cp .env.example .env.local
```

Editar `.env.local` con tus configuraciones:
```env
# Analytics
NEXT_PUBLIC_GA_ID=G-XXXXXXXXXX
NEXT_PUBLIC_FACEBOOK_PIXEL_ID=XXXXXXXXXX
NEXT_PUBLIC_LINKEDIN_ID=XXXXXXXXXX

# CRM Integration
NEXT_PUBLIC_CRM_API_URL=https://api.tu-crm.com
NEXT_PUBLIC_CRM_API_KEY=tu-api-key

# GeoIP Service
NEXT_PUBLIC_GEOIP_API_KEY=tu-geoip-key
```

4. **Ejecutar en desarrollo**
```bash
npm run dev
# o
yarn dev
```

5. **Abrir en el navegador**
```
http://localhost:3000
```

### Scripts Disponibles

```bash
# Desarrollo
npm run dev

# Build de producción
npm run build

# Iniciar servidor de producción
npm run start

# Linting
npm run lint

# Type checking
npm run type-check

# Análisis de bundle
npm run analyze
```

## 📊 Optimización de Conversión

### Estrategias Implementadas

#### 1. Personalización por Comportamiento
- **Tracking de páginas visitadas** - Contenido adaptativo
- **Tiempo en página** - CTAs dinámicos
- **Interacciones previas** - Formularios inteligentes

#### 2. Elementos de Urgencia
- **Ofertas limitadas** - Escasez temporal
- **Cupos disponibles** - Limitación de disponibilidad
- **Resultados rápidos** - Beneficios inmediatos

#### 3. Prueba Social Estratégica
- **Testimonios específicos** - Por industria y tamaño
- **Métricas impactantes** - ROI, tiempo, satisfacción
- **Logos de confianza** - Empresas reconocidas

#### 4. Optimización de Formularios
- **Progreso visual** - Indicador de pasos
- **Validación inteligente** - Feedback inmediato
- **Campos adaptativos** - Según respuestas previas

## 🔧 Configuración Avanzada

### Personalización por GeoIP

```typescript
// lib/geoip.ts
export const getLocalizedContent = (country: string) => {
  const content = {
    'ES': {
      currency: '€',
      phone: '+34',
      language: 'es',
    },
    'MX': {
      currency: '$',
      phone: '+52',
      language: 'es',
    },
    // ... más países
  };
  return content[country] || content['ES'];
};
```

### Integración con CRM

```typescript
// lib/crm.ts
export const submitLead = async (formData: LeadFormData) => {
  const response = await fetch('/api/leads', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(formData),
  });
  return response.json();
};
```

### Analytics Personalizado

```typescript
// lib/analytics.ts
export const trackConversion = (event: string, data: any) => {
  // Google Analytics 4
  gtag('event', event, data);
  
  // Facebook Pixel
  fbq('track', event, data);
  
  // LinkedIn Insight
  lintrk('track', { conversion_id: data.conversionId });
};
```

## 📈 Métricas y KPIs

### Métricas de Conversión
- **Tasa de conversión** - Objetivo: 5-8%
- **Tiempo en página** - Objetivo: 3+ minutos
- **Tasa de rebote** - Objetivo: <40%
- **Páginas por sesión** - Objetivo: 4+ páginas

### Métricas de Rendimiento
- **Core Web Vitals** - LCP < 2.5s, FID < 100ms, CLS < 0.1
- **PageSpeed Score** - Objetivo: 90+
- **SEO Score** - Objetivo: 95+

### Métricas de Negocio
- **Leads generados** - Seguimiento por fuente
- **ROI de marketing** - Análisis de conversión
- **CAC por canal** - Optimización de presupuesto

## 🚀 Despliegue

### Vercel (Recomendado)
```bash
npm install -g vercel
vercel
```

### Netlify
```bash
npm run build
# Subir carpeta .next a Netlify
```

### Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para detalles.

## 📞 Soporte

- **Email**: contacto@si-tus-supieras-ai.com
- **Teléfono**: +34 900 123 456
- **Documentación**: [docs.si-tus-supieras-ai.com](https://docs.si-tus-supieras-ai.com)

## 🙏 Agradecimientos

- Equipo de desarrollo de STS AI
- Comunidad de Next.js
- Contribuidores de Tailwind CSS
- Usuarios beta que proporcionaron feedback

---

**Desarrollado con ❤️ por el equipo de Si Tus Supieras El Poder de la IA** 
#!/bin/bash

# Script para ejecutar comandos en el servidor sin pedir contraseña
# Usar: ./deploy-remote.sh "comando"

SERVER="root@8.208.103.69"
PASSWORD="tu_contraseña_aqui"  # Reemplazar con tu contraseña real

if [ -z "$1" ]; then
    echo "Uso: $0 \"comando\""
    exit 1
fi

# Usar expect para automatizar SSH
expect << EOF
spawn ssh $SERVER "$1"
expect "password:"
send "$PASSWORD\r"
expect eof
EOF 
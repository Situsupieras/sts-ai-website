import { Metadata } from 'next';
import HeroSection from '@/components/sections/hero-section';
import ProblemAgitationSolution from '@/components/sections/problem-agitation-solution';
import SocialProof from '@/components/sections/social-proof';
import AIProcessVisualizer from '@/components/sections/ai-process-visualizer';
import IntelligentForm from '@/components/sections/intelligent-form';
import FeaturesSection from '@/components/sections/features-section';
import CTASection from '@/components/sections/cta-section';

export const metadata: Metadata = {
  title: 'Si Tu Supieras El Poder de la IA | Soluciones B2B de Inteligencia Artificial',
  description: 'Transforma tu empresa con soluciones de IA personalizadas. Automatización, análisis predictivo y optimización de procesos para empresas B2B.',
  keywords: [
    'inteligencia artificial',
    'IA empresarial',
    'automatización',
    'análisis predictivo',
    'machine learning',
    'B2B',
    'transformación digital',
    'optimización de procesos',
  ],
  openGraph: {
    title: 'Si Tu Supieras El Poder de la IA | Soluciones B2B de Inteligencia Artificial',
    description: 'Transforma tu empresa con soluciones de IA personalizadas. Automatización, análisis predictivo y optimización de procesos para empresas B2B.',
    url: 'https://si-tus-supieras-ai.com',
    siteName: 'Si Tu Supieras El Poder de la IA',
    images: [
      {
        url: '/images/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Si Tu Supieras El Poder de la IA',
      },
    ],
    locale: 'es_ES',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Si Tu Supieras El Poder de la IA | Soluciones B2B de Inteligencia Artificial',
    description: 'Transforma tu empresa con soluciones de IA personalizadas.',
    images: ['/images/og-image.jpg'],
  },
  alternates: {
    canonical: '/',
  },
};

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <HeroSection />

      {/* Problema → Agitación → Solución */}
      <ProblemAgitationSolution />

      {/* Prueba Social Multinivel */}
      <SocialProof />

      {/* Visualizador Interactivo del Proceso de IA */}
      <AIProcessVisualizer />

      {/* Características Principales */}
      <FeaturesSection />

      {/* Formulario Inteligente Multietapas */}
      <IntelligentForm />

      {/* CTA Final */}
      <CTASection />
    </div>
  );
} 
'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { 
  ArrowRight, 
  Clock, 
  CheckCircle, 
  Star,
  Zap,
  TrendingUp
} from 'lucide-react';

const CTASection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const benefits = [
    'Consulta gratuita sin compromiso',
    'Propuesta personalizada en 24h',
    'Implementación en 30 días',
    'ROI garantizado del 340%',
  ];

  const urgencyElements = [
    {
      icon: Clock,
      text: 'Oferta limitada: 50% descuento en implementación',
      color: 'text-red-500',
    },
    {
      icon: Star,
      text: 'Solo 3 cupos disponibles este mes',
      color: 'text-yellow-500',
    },
    {
      icon: Zap,
      text: 'Resultados visibles en las primeras 2 semanas',
      color: 'text-green-500',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-primary-600 via-primary-700 to-secondary-600 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-full h-full bg-black/10"></div>
        <div className="absolute top-20 left-20 w-32 h-32 bg-white/10 rounded-full animate-float"></div>
        <div className="absolute bottom-20 right-20 w-24 h-24 bg-white/10 rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-white/5 rounded-full animate-pulse-slow"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6"
          >
            ¿Listo para{' '}
            <span className="text-yellow-300">Transformar</span>{' '}
            tu Empresa?
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.4 }}
            className="text-xl text-white/90 max-w-3xl mx-auto mb-8"
          >
            Únete a más de 500 empresas que ya han experimentado el poder transformador de la IA. 
            Tu competencia ya está actuando. ¿Y tú?
          </motion.p>

          {/* Urgency Elements */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.6 }}
            className="flex flex-wrap justify-center items-center gap-6 mb-8"
          >
            {urgencyElements.map((element, index) => (
              <div key={index} className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                <element.icon className={`w-5 h-5 ${element.color}`} />
                <span className="text-white text-sm font-medium">{element.text}</span>
              </div>
            ))}
          </motion.div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Benefits */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
              <h3 className="text-2xl font-bold text-white mb-6">
                ¿Por qué elegirnos?
              </h3>
              
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <motion.div
                    key={benefit}
                    initial={{ opacity: 0, x: -20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: 1 + index * 0.1 }}
                    className="flex items-center space-x-3"
                  >
                    <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0" />
                    <span className="text-white/90">{benefit}</span>
                  </motion.div>
                ))}
              </div>

              {/* Social Proof */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 1.5 }}
                className="mt-8 p-4 bg-white/10 rounded-lg"
              >
                <div className="flex items-center justify-center space-x-1 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-white/80 text-sm text-center">
                  "La mejor decisión que tomamos para nuestra empresa. ROI del 340% en solo 6 meses."
                </p>
                <p className="text-white/60 text-xs text-center mt-2">
                  - María González, CEO TechCorp Solutions
                </p>
              </motion.div>
            </div>
          </motion.div>

          {/* CTA Form */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 1 }}
          >
            <div className="bg-white rounded-2xl p-8 shadow-2xl">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  Solicita tu Consulta Gratuita
                </h3>
                <p className="text-gray-600">
                  Recibe una propuesta personalizada en menos de 24 horas
                </p>
              </div>

              <form className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Nombre completo"
                    className="input w-full"
                    required
                  />
                </div>
                
                <div>
                  <input
                    type="email"
                    placeholder="Email corporativo"
                    className="input w-full"
                    required
                  />
                </div>
                
                <div>
                  <input
                    type="tel"
                    placeholder="Teléfono"
                    className="input w-full"
                  />
                </div>
                
                <div>
                  <input
                    type="text"
                    placeholder="Empresa"
                    className="input w-full"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full btn-primary btn-lg group"
                >
                  Solicitar Consulta Gratuita
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </button>
              </form>

              <div className="mt-6 text-center">
                <p className="text-xs text-gray-500">
                  Al enviar este formulario, aceptas recibir comunicaciones comerciales de Si Tu Supieras El Poder de la IA.
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Final CTA */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1.5 }}
          className="text-center mt-16"
        >
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-4">
              No esperes más
            </h3>
            <p className="text-white/90 mb-6">
              Cada día que esperas, tu competencia avanza. La IA no es el futuro, es el presente. 
              ¿Estás listo para liderar el cambio?
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-lg bg-white text-primary-600 hover:bg-gray-100 font-semibold rounded-lg px-8 py-3 transition-colors duration-200">
                <TrendingUp className="w-5 h-5 mr-2" />
                Comenzar Ahora
              </button>
              <button className="btn-lg border-2 border-white text-white hover:bg-white hover:text-primary-600 font-semibold rounded-lg px-8 py-3 transition-colors duration-200">
                Ver Demo en Vivo
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection; 
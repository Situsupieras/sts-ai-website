'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { 
  Database, 
  Brain, 
  Zap, 
  TrendingUp, 
  CheckCircle, 
  ArrowRight,
  Play,
  Pause,
  RotateCcw
} from 'lucide-react';
import React from 'react';

const AIProcessVisualizer = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const steps = [
    {
      id: 1,
      title: 'Recopilación de Datos',
      description: 'Recopilamos y estructuramos todos los datos relevantes de tu empresa',
      icon: Database,
      color: 'from-blue-500 to-blue-600',
      details: [
        'Análisis de fuentes de datos existentes',
        'Integración con sistemas actuales',
        'Limpieza y validación de datos',
        'Creación de pipelines de datos',
      ],
    },
    {
      id: 2,
      title: 'Análisis con IA',
      description: 'Nuestros algoritmos de machine learning procesan y analizan los datos',
      icon: Brain,
      color: 'from-purple-500 to-purple-600',
      details: [
        'Aplicación de algoritmos de ML',
        'Identificación de patrones ocultos',
        'Predicción de tendencias futuras',
        'Optimización de modelos',
      ],
    },
    {
      id: 3,
      title: 'Automatización Inteligente',
      description: 'Implementamos procesos automatizados basados en los insights de IA',
      icon: Zap,
      color: 'from-yellow-500 to-yellow-600',
      details: [
        'Automatización de tareas repetitivas',
        'Chatbots inteligentes 24/7',
        'Sistemas de recomendación',
        'Alertas automáticas',
      ],
    },
    {
      id: 4,
      title: 'Optimización Continua',
      description: 'Monitoreamos y mejoramos constantemente el rendimiento del sistema',
      icon: TrendingUp,
      color: 'from-green-500 to-green-600',
      details: [
        'Monitoreo en tiempo real',
        'Ajustes automáticos de parámetros',
        'Mejoras incrementales',
        'Reportes de rendimiento',
      ],
    },
    {
      id: 5,
      title: 'Resultados Medibles',
      description: 'Obtienes resultados tangibles y medibles en tu negocio',
      icon: CheckCircle,
      color: 'from-emerald-500 to-emerald-600',
      details: [
        'Incremento del 340% en ROI',
        'Reducción del 70% en costos',
        'Mejora del 95% en eficiencia',
        'Satisfacción del cliente al 98%',
      ],
    },
  ];

  const handleNext = () => {
    setCurrentStep((prev) => (prev + 1) % steps.length);
  };

  const handlePrev = () => {
    setCurrentStep((prev) => (prev - 1 + steps.length) % steps.length);
  };

  const handlePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setCurrentStep(0);
    setIsPlaying(false);
  };

  // Auto-play functionality
  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setCurrentStep((prev) => (prev + 1) % steps.length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [isPlaying]);

  return (
    <section className="py-20 bg-gray-50 dark:bg-dark-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Cómo Funciona Nuestro{' '}
            <span className="gradient-text">Proceso de IA</span>
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Un enfoque sistemático y probado que transforma tu empresa paso a paso
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Process Visualization */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="bg-white dark:bg-dark-700 rounded-2xl p-8 shadow-lg">
              {/* Process Steps */}
              <div className="space-y-6">
                {steps.map((step, index) => (
                  <motion.div
                    key={step.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: index * 0.1 }}
                    className={`relative flex items-center space-x-4 p-4 rounded-lg transition-all duration-300 cursor-pointer ${
                      currentStep === index
                        ? 'bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20 border-2 border-primary-200 dark:border-primary-700'
                        : 'bg-gray-50 dark:bg-dark-600'
                    }`}
                    onClick={() => setCurrentStep(index)}
                  >
                    {/* Step Number */}
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-white ${
                      currentStep === index
                        ? 'bg-gradient-to-r from-primary-500 to-secondary-500'
                        : 'bg-gray-400'
                    }`}>
                      {step.id}
                    </div>

                    {/* Step Content */}
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 dark:text-white">
                        {step.title}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {step.description}
                      </p>
                    </div>

                    {/* Active Indicator */}
                    {currentStep === index && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-3 h-3 bg-primary-500 rounded-full"
                      />
                    )}
                  </motion.div>
                ))}
              </div>

              {/* Controls */}
              <div className="flex items-center justify-center space-x-4 mt-8">
                <button
                  onClick={handlePrev}
                  className="p-2 rounded-lg bg-gray-100 dark:bg-dark-600 hover:bg-gray-200 dark:hover:bg-dark-500 transition-colors"
                >
                  <ArrowRight className="w-5 h-5 rotate-180" />
                </button>
                
                <button
                  onClick={handlePlay}
                  className="p-3 rounded-lg bg-primary-500 hover:bg-primary-600 text-white transition-colors"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </button>
                
                <button
                  onClick={handleNext}
                  className="p-2 rounded-lg bg-gray-100 dark:bg-dark-600 hover:bg-gray-200 dark:hover:bg-dark-500 transition-colors"
                >
                  <ArrowRight className="w-5 h-5" />
                </button>
                
                <button
                  onClick={handleReset}
                  className="p-2 rounded-lg bg-gray-100 dark:bg-dark-600 hover:bg-gray-200 dark:hover:bg-dark-500 transition-colors"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>

          {/* Step Details */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative"
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
                className="bg-white dark:bg-dark-700 rounded-2xl p-8 shadow-lg h-full"
              >
                <div className="text-center mb-8">
                  <div className={`w-20 h-20 mx-auto mb-4 bg-gradient-to-r ${steps[currentStep].color} rounded-full flex items-center justify-center`}>
                    {React.createElement(steps[currentStep].icon, { className: "w-10 h-10 text-white" })}
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    {steps[currentStep].title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {steps[currentStep].description}
                  </p>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-4">
                    Lo que incluye:
                  </h4>
                  <ul className="space-y-3">
                    {steps[currentStep].details.map((detail, index) => (
                      <motion.li
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-start space-x-3"
                      >
                        <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700 dark:text-gray-300">{detail}</span>
                      </motion.li>
                    ))}
                  </ul>
                </div>

                {/* Progress Indicator */}
                <div className="mt-8">
                  <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                    <span>Paso {currentStep + 1} de {steps.length}</span>
                    <span>{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-dark-600 rounded-full h-2">
                    <motion.div
                      className="bg-gradient-to-r from-primary-500 to-secondary-500 h-2 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1 }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-primary-500 to-secondary-500 rounded-2xl p-8 text-white max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">
              ¿Te gustaría ver este proceso en acción?
            </h3>
            <p className="text-white/90 mb-6">
              Agenda una demostración personalizada y descubre cómo podemos transformar tu empresa con IA.
            </p>
            <button className="btn-lg bg-white text-primary-600 hover:bg-gray-100 font-semibold rounded-lg px-8 py-3 transition-colors duration-200">
              Solicitar Demo Personalizada
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AIProcessVisualizer; 
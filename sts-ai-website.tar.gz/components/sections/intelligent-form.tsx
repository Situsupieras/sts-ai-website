'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle, 
  Building, 
  Users, 
  Target,
  Mail,
  Phone,
  MessageSquare,
  Send
} from 'lucide-react';

const IntelligentForm = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    industry: '',
    companySize: '',
    challenges: [] as string[],
    budget: '',
    timeline: '',
    message: '',
  });

  const steps = [
    {
      id: 1,
      title: 'Información Básica',
      description: 'Cuéntanos sobre ti y tu empresa',
      fields: ['name', 'email', 'phone', 'company'],
    },
    {
      id: 2,
      title: 'Contexto Empresarial',
      description: 'Entendemos mejor tu industria y necesidades',
      fields: ['industry', 'companySize'],
    },
    {
      id: 3,
      title: 'Desafíos Específicos',
      description: 'Identificamos los problemas que podemos resolver',
      fields: ['challenges'],
    },
    {
      id: 4,
      title: 'Proyecto y Presupuesto',
      description: 'Definimos el alcance y recursos',
      fields: ['budget', 'timeline'],
    },
    {
      id: 5,
      title: 'Mensaje Personalizado',
      description: 'Comparte cualquier información adicional',
      fields: ['message'],
    },
  ];

  const industries = [
    'Fintech',
    'E-commerce',
    'Healthcare',
    'Manufactura',
    'Logística',
    'Educación',
    'Real Estate',
    'Otro',
  ];

  const companySizes = [
    '1-10 empleados',
    '11-50 empleados',
    '51-200 empleados',
    '201-1000 empleados',
    '1000+ empleados',
  ];

  const challenges = [
    'Automatización de procesos',
    'Análisis de datos',
    'Servicio al cliente',
    'Optimización de costos',
    'Escalabilidad',
    'Toma de decisiones',
    'Seguridad de datos',
    'Integración de sistemas',
  ];

  const budgets = [
    '€5,000 - €15,000',
    '€15,000 - €50,000',
    '€50,000 - €100,000',
    '€100,000+',
    'Por definir',
  ];

  const timelines = [
    'Inmediato (1-2 meses)',
    'Corto plazo (3-6 meses)',
    'Mediano plazo (6-12 meses)',
    'Largo plazo (12+ meses)',
  ];

  const handleInputChange = (field: string, value: string | string[]) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form data:', formData);
  };

  const isStepValid = (stepIndex: number) => {
    const step = steps[stepIndex];
    return step.fields.every(field => {
      const value = formData[field as keyof typeof formData];
      if (Array.isArray(value)) {
        return value.length > 0;
      }
      return value && value.trim() !== '';
    });
  };

  const renderField = (field: string) => {
    switch (field) {
      case 'name':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Nombre completo *
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              className="input w-full"
              placeholder="Tu nombre completo"
              required
            />
          </div>
        );

      case 'email':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Email corporativo *
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              className="input w-full"
              placeholder="tu@empresa.com"
              required
            />
          </div>
        );

      case 'phone':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Teléfono
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              className="input w-full"
              placeholder="+34 600 000 000"
            />
          </div>
        );

      case 'company':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Empresa *
            </label>
            <input
              type="text"
              value={formData.company}
              onChange={(e) => handleInputChange('company', e.target.value)}
              className="input w-full"
              placeholder="Nombre de tu empresa"
              required
            />
          </div>
        );

      case 'industry':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Industria *
            </label>
            <select
              value={formData.industry}
              onChange={(e) => handleInputChange('industry', e.target.value)}
              className="input w-full"
              required
            >
              <option value="">Selecciona tu industria</option>
              {industries.map((industry) => (
                <option key={industry} value={industry}>
                  {industry}
                </option>
              ))}
            </select>
          </div>
        );

      case 'companySize':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Tamaño de la empresa *
            </label>
            <select
              value={formData.companySize}
              onChange={(e) => handleInputChange('companySize', e.target.value)}
              className="input w-full"
              required
            >
              <option value="">Selecciona el tamaño</option>
              {companySizes.map((size) => (
                <option key={size} value={size}>
                  {size}
                </option>
              ))}
            </select>
          </div>
        );

      case 'challenges':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Desafíos principales (selecciona todos los que apliquen) *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {challenges.map((challenge) => (
                <label key={challenge} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.challenges.includes(challenge)}
                    onChange={(e) => {
                      const newChallenges = e.target.checked
                        ? [...formData.challenges, challenge]
                        : formData.challenges.filter(c => c !== challenge);
                      handleInputChange('challenges', newChallenges);
                    }}
                    className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
                  />
                  <span className="text-sm text-gray-700 dark:text-gray-300">{challenge}</span>
                </label>
              ))}
            </div>
          </div>
        );

      case 'budget':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Presupuesto estimado
            </label>
            <select
              value={formData.budget}
              onChange={(e) => handleInputChange('budget', e.target.value)}
              className="input w-full"
            >
              <option value="">Selecciona un rango</option>
              {budgets.map((budget) => (
                <option key={budget} value={budget}>
                  {budget}
                </option>
              ))}
            </select>
          </div>
        );

      case 'timeline':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Timeline del proyecto
            </label>
            <select
              value={formData.timeline}
              onChange={(e) => handleInputChange('timeline', e.target.value)}
              className="input w-full"
            >
              <option value="">Selecciona un timeline</option>
              {timelines.map((timeline) => (
                <option key={timeline} value={timeline}>
                  {timeline}
                </option>
              ))}
            </select>
          </div>
        );

      case 'message':
        return (
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Mensaje adicional
            </label>
            <textarea
              value={formData.message}
              onChange={(e) => handleInputChange('message', e.target.value)}
              className="textarea w-full"
              placeholder="Cuéntanos más sobre tu proyecto, objetivos específicos o cualquier pregunta que tengas..."
              rows={4}
            />
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <section className="py-20 bg-white dark:bg-dark-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Solicita tu{' '}
            <span className="gradient-text">Consulta Gratuita</span>
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Completa este formulario inteligente y recibe una propuesta personalizada en menos de 24 horas
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white dark:bg-dark-700 rounded-2xl shadow-lg overflow-hidden">
            {/* Progress Bar */}
            <div className="bg-gray-50 dark:bg-dark-800 p-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Paso {currentStep + 1} de {steps.length}
                </span>
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {Math.round(((currentStep + 1) / steps.length) * 100)}% completado
                </span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-dark-600 rounded-full h-2">
                <motion.div
                  className="bg-gradient-to-r from-primary-500 to-secondary-500 h-2 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>

            {/* Form Content */}
            <div className="p-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentStep}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                      {steps[currentStep].title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {steps[currentStep].description}
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {steps[currentStep].fields.map((field) => (
                        <div key={field} className={field === 'challenges' || field === 'message' ? 'md:col-span-2' : ''}>
                          {renderField(field)}
                        </div>
                      ))}
                    </div>

                    {/* Navigation Buttons */}
                    <div className="flex justify-between pt-6">
                      <button
                        type="button"
                        onClick={handlePrev}
                        disabled={currentStep === 0}
                        className="btn-outline btn-md disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Anterior
                      </button>

                      {currentStep < steps.length - 1 ? (
                        <button
                          type="button"
                          onClick={handleNext}
                          disabled={!isStepValid(currentStep)}
                          className="btn-primary btn-md disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Siguiente
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </button>
                      ) : (
                        <button
                          type="submit"
                          className="btn-primary btn-md"
                        >
                          <Send className="w-4 h-4 mr-2" />
                          Enviar Consulta
                        </button>
                      )}
                    </div>
                  </form>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          {/* Trust Indicators */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.5 }}
            className="mt-8 text-center"
          >
            <div className="flex flex-wrap justify-center items-center space-x-8 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>Consulta gratuita</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>Respuesta en 24h</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>Sin compromiso</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default IntelligentForm; 
'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { AlertTriangle, TrendingDown, Rocket, CheckCircle, XCircle, Zap } from 'lucide-react';

const ProblemAgitationSolution = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const problems = [
    'Procesos manuales lentos y costosos',
    'Pérdida de oportunidades por falta de datos',
    'Errores humanos que afectan la productividad',
    'Escalabilidad limitada del negocio',
    'Toma de decisiones basada en intuición',
  ];

  const consequences = [
    'Pérdidas de hasta €500,000 anuales',
    'Competitividad reducida en el mercado',
    'Frustración del equipo y clientes',
    'Oportunidades perdidas de crecimiento',
    'Riesgo de obsolescencia tecnológica',
  ];

  const solutions = [
    'Automatización inteligente de procesos',
    'Análisis predictivo en tiempo real',
    'Chatbots avanzados 24/7',
    'Optimización basada en IA',
    'Decisiones data-driven',
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
      },
    },
  };

  return (
    <section className="py-20 bg-gray-50 dark:bg-dark-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="text-center mb-16"
        >
          <motion.h2
            variants={itemVariants}
            className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-6"
          >
            El{' '}
            <span className="gradient-text">Problema</span>{' '}
            que Resolvemos
          </motion.h2>
          <motion.p
            variants={itemVariants}
            className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto"
          >
            Las empresas modernas enfrentan desafíos críticos que la IA puede resolver de manera efectiva
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* PROBLEMA */}
          <motion.div
            variants={itemVariants}
            className="relative"
          >
            <div className="bg-white dark:bg-dark-700 rounded-2xl p-8 shadow-lg border-l-4 border-red-500 h-full">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900 rounded-lg flex items-center justify-center mr-4">
                  <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                  El Problema
                </h3>
              </div>
              
              <ul className="space-y-4">
                {problems.map((problem, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start space-x-3"
                  >
                    <XCircle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700 dark:text-gray-300">{problem}</span>
                  </motion.li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* AGITACIÓN */}
          <motion.div
            variants={itemVariants}
            className="relative"
          >
            <div className="bg-white dark:bg-dark-700 rounded-2xl p-8 shadow-lg border-l-4 border-orange-500 h-full">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center mr-4">
                  <TrendingDown className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                  La Agitación
                </h3>
              </div>
              
              <ul className="space-y-4">
                {consequences.map((consequence, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: index * 0.1 + 0.3 }}
                    className="flex items-start space-x-3"
                  >
                    <div className="w-5 h-5 bg-orange-500 rounded-full mt-0.5 flex-shrink-0"></div>
                    <span className="text-gray-700 dark:text-gray-300">{consequence}</span>
                  </motion.li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* SOLUCIÓN */}
          <motion.div
            variants={itemVariants}
            className="relative"
          >
            <div className="bg-gradient-to-br from-primary-500 to-secondary-500 rounded-2xl p-8 shadow-lg text-white h-full relative overflow-hidden">
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full -mr-16 -mt-16"></div>
                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white rounded-full -ml-12 -mb-12"></div>
              </div>
              
              <div className="relative z-10">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center mr-4">
                    <Rocket className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-white">
                    Nuestra Solución
                  </h3>
                </div>
                
                <ul className="space-y-4">
                  {solutions.map((solution, index) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={inView ? { opacity: 1, x: 0 } : {}}
                      transition={{ delay: index * 0.1 + 0.6 }}
                      className="flex items-start space-x-3"
                    >
                      <CheckCircle className="w-5 h-5 text-white mt-0.5 flex-shrink-0" />
                      <span className="text-white/90">{solution}</span>
                    </motion.li>
                  ))}
                </ul>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 1.2 }}
                  className="mt-8 p-4 bg-white/10 backdrop-blur-sm rounded-lg"
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <Zap className="w-5 h-5 text-yellow-300" />
                    <span className="font-semibold">Resultado Esperado:</span>
                  </div>
                  <p className="text-white/90 text-sm">
                    Incremento del 340% en ROI y reducción del 70% en costos operativos en los primeros 6 meses.
                  </p>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1.5 }}
          className="text-center mt-16"
        >
          <div className="bg-white dark:bg-dark-700 rounded-2xl p-8 shadow-lg max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              ¿Te identificas con estos problemas?
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              No esperes más. Nuestras soluciones de IA están diseñadas específicamente para resolver estos desafíos.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary btn-lg">
                Solicitar Consulta Gratuita
              </button>
              <button className="btn-outline btn-lg">
                Ver Casos de Éxito
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ProblemAgitationSolution; 
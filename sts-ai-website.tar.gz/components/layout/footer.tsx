'use client';

import Link from 'next/link';
import { Facebook, Twitter, Linkedin, Instagram, Mail, Phone, MapPin } from 'lucide-react';

const footerLinks = {
  soluciones: [
    { name: 'Automatización', href: '/soluciones/automatizacion' },
    { name: 'Análisis Predictivo', href: '/soluciones/analisis-predictivo' },
    { name: 'Chatbots Inteligentes', href: '/soluciones/chatbots' },
    { name: 'Optimización de Procesos', href: '/soluciones/optimizacion' },
  ],
  industrias: [
    { name: 'Fintech', href: '/industrias/fintech' },
    { name: 'E-commerce', href: '/industrias/ecommerce' },
    { name: 'Healthcare', href: '/industrias/healthcare' },
    { name: 'Manufactura', href: '/industrias/manufactura' },
  ],
  recursos: [
    { name: 'Blog', href: '/blog' },
    { name: 'Whitepapers', href: '/recursos/whitepapers' },
    { name: 'Webinars', href: '/recursos/webinars' },
    { name: 'Casos de Estudio', href: '/recursos/casos-estudio' },
  ],
  empresa: [
    { name: 'Sobre Nosotros', href: '/nosotros' },
    { name: 'Equipo', href: '/nosotros/equipo' },
    { name: 'Carreras', href: '/carreras' },
    { name: 'Contacto', href: '/contacto' },
  ],
};

const socialLinks = [
  { name: 'Facebook', href: '#', icon: Facebook },
  { name: 'Twitter', href: '#', icon: Twitter },
  { name: 'LinkedIn', href: '#', icon: Linkedin },
  { name: 'Instagram', href: '#', icon: Instagram },
];

export default function Footer() {
  return (
    <footer className="bg-dark-900 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">STS</span>
              </div>
              <span className="text-2xl font-bold gradient-text">
                Si Tu Supieras El Poder de la IA
              </span>
            </Link>
            <p className="text-gray-300 mb-6 max-w-md">
              Transformamos empresas con soluciones de inteligencia artificial personalizadas. 
              Automatización, análisis predictivo y optimización de procesos para el éxito empresarial.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3 text-gray-300">
                <Mail className="w-5 h-5 text-primary-400" />
                <span>contacto@si-tus-supieras-ai.com</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <Phone className="w-5 h-5 text-primary-400" />
                <span>+34 900 123 456</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-300">
                <MapPin className="w-5 h-5 text-primary-400" />
                <span>Madrid, España</span>
              </div>
            </div>
          </div>

          {/* Soluciones */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Soluciones</h3>
            <ul className="space-y-2">
              {footerLinks.soluciones.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-300 hover:text-primary-400 transition-colors duration-200"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Industrias */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Industrias</h3>
            <ul className="space-y-2">
              {footerLinks.industrias.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-300 hover:text-primary-400 transition-colors duration-200"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Recursos */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Recursos</h3>
            <ul className="space-y-2">
              {footerLinks.recursos.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-gray-300 hover:text-primary-400 transition-colors duration-200"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-dark-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex items-center space-x-6">
              {socialLinks.map((social) => (
                <Link
                  key={social.name}
                  href={social.href}
                  className="text-gray-400 hover:text-primary-400 transition-colors duration-200"
                  aria-label={social.name}
                >
                  <social.icon className="w-5 h-5" />
                </Link>
              ))}
            </div>
            
            <div className="flex items-center space-x-6 text-sm text-gray-400">
              <Link href="/privacidad" className="hover:text-primary-400 transition-colors duration-200">
                Política de Privacidad
              </Link>
              <Link href="/terminos" className="hover:text-primary-400 transition-colors duration-200">
                Términos de Servicio
              </Link>
              <Link href="/cookies" className="hover:text-primary-400 transition-colors duration-200">
                Política de Cookies
              </Link>
            </div>
          </div>
          
          <div className="text-center mt-6 pt-6 border-t border-dark-700">
            <p className="text-gray-400 text-sm">
              © {new Date().getFullYear()} Si Tu Supieras El Poder de la IA. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
} 
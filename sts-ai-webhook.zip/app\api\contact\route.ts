import { NextRequest, NextResponse } from 'next/server';

// Configuración del webhook - Cambia esta URL por la de tu webhook
const WEBHOOK_URL = process.env.WEBHOOK_URL || 'https://hooks.zapier.com/hooks/catch/your-webhook-url';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    console.log('Form submission received:', JSON.stringify(body, null, 2));

    // Procesar los datos del formulario en fases
    const processedData = {
      // Información básica
      name: `${body.firstName || ''} ${body.lastName || ''}`.trim(),
      email: body.email || '',
      phone: body.phone || '',
      company: body.company || '',
      position: body.position || '',
      industry: body.industry || '',
      
      // Información del negocio
      companySize: body.companySize || '',
      annualRevenue: body.annualRevenue || '',
      currentChallenges: body.currentChallenges || [],
      
      // Objetivos y timeline
      primaryGoal: body.primaryGoal || '',
      timeline: body.timeline || '',
      budget: body.budget || '',
      
      // Información adicional
      currentTools: body.currentTools || [],
      teamSize: body.teamSize || '',
      decisionMaker: body.decisionMaker || false,
      
      // Lead scoring
      leadScore: body.leadScore || 0,
      urgency: body.urgency || '',
      authority: body.authority || '',
      need: body.need || '',
      
      // Metadata
      submittedAt: body.submittedAt || new Date().toISOString(),
      source: body.source || 'landing-page',
      utmSource: body.utmSource || 'direct'
    };

    // Enviar datos al webhook externo
    console.log('Sending data to webhook:', WEBHOOK_URL);
    
    const webhookResponse = await fetch(WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ...processedData,
        webhook_received_at: new Date().toISOString(),
        form_source: 'sts-ai-landing-page'
      }),
    });

    console.log('Webhook response status:', webhookResponse.status);
    
    if (!webhookResponse.ok) {
      const errorText = await webhookResponse.text();
      console.error('Webhook error:', errorText);
      throw new Error(`Webhook failed: ${webhookResponse.status}`);
    }

    const webhookData = await webhookResponse.text();
    console.log('Webhook response:', webhookData);

    // Respuesta exitosa
    const response = {
      success: true,
      message: '¡Gracias por tu interés! Te contactaremos pronto.',
      data: processedData,
      leadScore: processedData.leadScore,
      priority: processedData.leadScore >= 80 ? 'alta' : 
                processedData.leadScore >= 60 ? 'media' : 'baja',
      webhook_sent: true,
      webhook_status: webhookResponse.status
    };

    console.log('Sending response:', JSON.stringify(response, null, 2));

    return NextResponse.json(response);

  } catch (error) {
    console.error('API Error:', error);
    
    // Respuesta de fallback - aún enviamos respuesta exitosa al usuario
    return NextResponse.json({
      success: true,
      message: '¡Gracias por tu interés! Te contactaremos pronto.',
      data: {
        submittedAt: new Date().toISOString()
      },
      webhook_sent: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}

export async function GET() {
  return NextResponse.json({ 
    success: true, 
    message: 'API de contacto funcionando correctamente',
    webhook_url: WEBHOOK_URL,
    timestamp: new Date().toISOString()
  });
} 
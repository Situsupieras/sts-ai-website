import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    console.log('Form submission received:', JSON.stringify(body, null, 2));

    // Procesar los datos del formulario en fases
    const processedData = {
      // Información básica
      name: `${body.firstName || ''} ${body.lastName || ''}`.trim(),
      email: body.email || '',
      phone: body.phone || '',
      company: body.company || '',
      position: body.position || '',
      industry: body.industry || '',
      
      // Información del negocio
      companySize: body.companySize || '',
      annualRevenue: body.annualRevenue || '',
      currentChallenges: body.currentChallenges || [],
      
      // Objetivos y timeline
      primaryGoal: body.primaryGoal || '',
      timeline: body.timeline || '',
      budget: body.budget || '',
      
      // Información adicional
      currentTools: body.currentTools || [],
      teamSize: body.teamSize || '',
      decisionMaker: body.decisionMaker || false,
      
      // Lead scoring
      leadScore: body.leadScore || 0,
      urgency: body.urgency || '',
      authority: body.authority || '',
      need: body.need || '',
      
      // Metadata
      submittedAt: body.submittedAt || new Date().toISOString(),
      source: body.source || 'landing-page',
      utmSource: body.utmSource || 'direct'
    };

    // Simular procesamiento exitoso
    const response = {
      success: true,
      message: '¡Gracias por tu interés! Te contactaremos pronto.',
      data: processedData,
      leadScore: processedData.leadScore,
      priority: processedData.leadScore >= 80 ? 'alta' : 
                processedData.leadScore >= 60 ? 'media' : 'baja'
    };

    console.log('Sending response:', JSON.stringify(response, null, 2));

    return NextResponse.json(response);

  } catch (error) {
    console.error('API Error:', error);
    
    // Respuesta de fallback
    return NextResponse.json({
      success: true,
      message: '¡Gracias por tu interés! Te contactaremos pronto.',
      data: {
        submittedAt: new Date().toISOString()
      }
    });
  }
}

export async function GET() {
  return NextResponse.json({ 
    success: true, 
    message: 'API de contacto funcionando correctamente',
    timestamp: new Date().toISOString()
  });
} 